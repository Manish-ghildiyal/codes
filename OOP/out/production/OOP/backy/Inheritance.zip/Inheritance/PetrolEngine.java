package backy.Inheritance;

public class PetrolEngine extends Engine {
    @Override
    public void start()
    {
        System.out.println("i start like a petrol engine");
    }
    public void makenoise(){
        System.out.println("hurr_hurr");
    }
    public static void hi()
    {
        System.out.println("horri hai");
    }


    public void fun()
    {
        System.out.println("done");
    }
}

